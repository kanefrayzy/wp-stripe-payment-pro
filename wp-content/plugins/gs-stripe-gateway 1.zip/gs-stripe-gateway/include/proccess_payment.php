<?php
if (!defined('ABSPATH')) die();

function stripe_process_payment_action() {
    if (strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } else {
        $data = $_POST;
    }

    if (!isset($data['nonce1']) || !wp_verify_nonce($data['nonce1'], 'stripe_payment_nonce')) {
        wp_send_json_error(['message' => 'Invalid nonce']);
        wp_die();
    }

    $args = [
        'page_id' => isset($data['page_id']) ? intval($data['page_id']) : 0,
        'product' => sanitize_text_field(get_post_meta($data['page_id'], 'product', true)),
        'total_payments' => isset($data['payments']) ? sanitize_text_field($data['payments']) : '',
        'email' => isset($data['email']) ? sanitize_email($data['email']) : '',
        'name' => isset($data['firstName']) ? sanitize_text_field($data['firstName']) : '',
        'lname' => isset($data['lastName']) ? sanitize_text_field($data['lastName']) : '',
        'phone' => isset($data['phone']) ? sanitize_text_field($data['phone']) : '',
        'price_id' => isset($data['price_id']) ? sanitize_text_field($data['price_id']) : '',
        'support_agent' => isset($data['support_agent']) ? sanitize_text_field($data['support_agent']) : '',
        'thank_you_page' => esc_url(get_post_meta($data['page_id'], 'thankyou', true)),
        'coupon_code' => isset($data['coupon']) ? sanitize_text_field($data['coupon']) : '',
        'payment_method_id' => isset($data['payment_method_id']) ? sanitize_text_field($data['payment_method_id']) : '',
        'origin' => get_site_url(),
    ];

    if (empty($args['thank_you_page'])) {
        $args['thank_you_page'] = home_url('/thank-you');
    }

    $processor = new StripePaymentProcessor($args);
    $processor->processPayment();

    wp_die();
}

add_action('wp_ajax_stripe_process_payment', 'stripe_process_payment_action');
add_action('wp_ajax_nopriv_stripe_process_payment', 'stripe_process_payment_action');