<?php

require_once('../../../../wp-load.php');
wp_send_json_success([
    'requires_action' => true,
    'payment_intent_client_secret' => $paymentIntent->client_secret,
]);

//$payment_intent_id = $_GET['payment_intent'] ?? null;
//echo $payment_intent_id;

/*include_once(plugin_dir_path(__DIR__) . 'vendor/autoload.php');

\Stripe\Stripe::setApiKey('your_stripe_secret_key');

// קבלת PaymentIntent ID מהפרמטרים ב-URL
$payment_intent_id = $_GET['payment_intent'] ?? null;

if ($payment_intent_id) {
    try {
        $payment_intent = \Stripe\PaymentIntent::retrieve($payment_intent_id);

        if ($payment_intent->status === 'succeeded') {
            echo "התשלום הושלם בהצלחה!";
            // בצע לוגיקה נוספת, כמו עדכון מסד הנתונים
        } else {
            echo "התשלום לא הושלם. סטטוס: " . $payment_intent->status;
        }
    } catch (\Stripe\Exception\ApiErrorException $e) {
        echo "שגיאה בבדיקת סטטוס התשלום: " . $e->getMessage();
    }
} else {
    echo "לא נמצא PaymentIntent ID";
}*/