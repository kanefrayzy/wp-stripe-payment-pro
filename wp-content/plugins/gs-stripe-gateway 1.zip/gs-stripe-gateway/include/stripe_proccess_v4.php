<?php
if (!defined('ABSPATH')) die();

class StripePaymentProcessor {
    private $stripe;
    private $args;

    public function __construct($args) {
        $this->args = $args;
        $this->initializeStripe();
    }

    private function initializeStripe() {
        $testmode = get_post_meta($this->args['page_id'], 'testmode', true);
        $frkey = $testmode ? get_option('product_key_field_dev') : get_option('product_key_field_prod');
        \Stripe\Stripe::setApiKey($frkey);
        $this->stripe = new \Stripe\StripeClient($frkey);
    }

    public function processPayment() {
        $this->validateInput();
        $customer_id = $this->getOrCreateCustomer();
        $this->attachPaymentMethod($customer_id);

        $this->args['customer_id'] = $customer_id;

        if ($this->args['total_payments'] == 1) {
            return $this->onePayment();
        } else {
            return $this->manyPayments();
        }
    }

    private function validateInput() {
        if (empty($this->args['total_payments']) || empty($this->args['email']) || empty($this->args['name']) || empty($this->args['phone'])) {
            wp_send_json_error(["message" => 'mandatory fields missing', "color" => "red"]);
        }

        $product = $this->stripe->products->retrieve($this->args['product'], []);
        if (!isset($product)) {
            wp_send_json_error(["message" => 'No Product ID', "color" => "red"]);
            wp_die();
        }

        $this->args['seleced_price'] = $this->stripe->prices->retrieve($this->args['price_id'], []);
        $max_payments_limit = $product->metadata->payment_limit ?? '';

        if ($this->args['total_payments'] > $max_payments_limit) {
            wp_send_json_error(["message" => "מקסימום $max_payments_limit תשלומים מורשים", "color" => "red"]);
            exit;
        }

        if ($this->args['seleced_price']->active != true) {
            wp_send_json_error(["message" => "המחיר לא פעיל בסטרייפ", "color" => "red"]);
            exit;
        }

        // Set amount and currency
        $this->args['amount'] = $this->args['seleced_price']->unit_amount;
        $this->args['currency'] = $this->args['seleced_price']->currency;
    }

    private function getOrCreateCustomer() {
        try {
            $customers = \Stripe\Customer::all(['email' => $this->args['email']]);
            if (count($customers->data) > 0) {
                return $customers->data[0]->id;
            } else {
                $customer = \Stripe\Customer::create([
                    'email' => $this->args['email'],
                    'name' => "{$this->args['name']} {$this->args['lname']}",
                    'phone' => $this->args['phone'],
                ]);
                return $customer->id;
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            wp_send_json_error(['message' => 'Error creating or retrieving customer: ' . $e->getMessage()]);
            return null;
        }
    }

    private function attachPaymentMethod($customer_id) {
        try {
            $this->stripe->paymentMethods->attach(
                $this->args['payment_method_id'],
                ['customer' => $customer_id]
            );

            $this->stripe->customers->update($customer_id, [
                'invoice_settings' => ['default_payment_method' => $this->args['payment_method_id']],
            ]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            wp_send_json_error(['message' => 'Error attaching payment method: ' . $e->getMessage()]);
            return;
        }
    }

    private function onePayment() {
        try {
            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount' => $this->args['amount'],
                'currency' => $this->args['currency'],
                'customer' => $this->args['customer_id'],
                'payment_method' => $this->args['payment_method_id'],
                'confirmation_method' => 'automatic',
                'confirm' => true,
                'setup_future_usage' => 'off_session',
                'return_url' => $this->args['thank_you_page'],
                'metadata' => [
                    'origin' => $this->args['origin'],
                    'app_payment_method'=> 'one_time',
                    'support_agent' => $this->args['support_agent'],
                    'transaction_id' => base64_encode(date("Y-m-d H:i:s")),
                ],
            ]);

            if ($paymentIntent->status === 'requires_action' && $paymentIntent->next_action->type === 'redirect_to_url') {
                $this->setOrder('requires_action', 'one_payment', $paymentIntent->id);
                wp_send_json_success([
                    'requires_action' => true,
                    'payment_intent_client_secret' => $paymentIntent->client_secret,
                    'message' => 'Payment requires additional authentication.',
                ]);
            } elseif ($paymentIntent->status === 'succeeded') {
                $invoice = $this->createInvoice();
                $this->setOrder('payment_succeeded', 'one_payment', $paymentIntent->id, $invoice->id);
                wp_send_json_success([
                    'message' => 'Payment succeeded.',
                    'payment_intent_id' => $paymentIntent->id,
                    'invoice_id' => $invoice->id,
                ]);
            } else {
                wp_send_json_error(['message' => 'Payment failed. Status: ' . $paymentIntent->status]);
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            $this->setOrder('error', 'one_payment', null, null, $e->getMessage());
            error_log('Payment processing error: ' . $e->getMessage());
            wp_send_json_error(['message' => 'Error processing payment: ' . $e->getMessage()]);
        }
    }

    private function manyPayments() {
        try {
            $subscription = \Stripe\Subscription::create([
                'customer' => $this->args['customer_id'],
                'items' => [['price' => $this->args['price_id']]],
                'payment_behavior' => 'allow_incomplete',
                'expand' => ['latest_invoice.payment_intent'],
                'metadata' => [
                    'origin' => $this->args['origin'],
                    'support_agent' => $this->args['support_agent'],
                    'transaction_id' => base64_encode(date("Y-m-d H:i:s")),
                ],
            ]);

            $paymentIntent = $subscription->latest_invoice->payment_intent;
            $invoice = $subscription->latest_invoice;

            if ($paymentIntent->status === 'requires_action') {
                $this->setOrder('requires_action', 'many_payments', $paymentIntent->id, $invoice->id, null, $subscription->id);
                wp_send_json_success([
                    'requires_action' => true,
                    'payment_intent_client_secret' => $paymentIntent->client_secret,
                    'message' => 'Subscription requires additional authentication.',
                ]);
            } else {
                if ($invoice->status === 'draft') {
                    $invoice->finalizeInvoice();
                }
                $this->setOrder('payment_succeeded', 'many_payments', $paymentIntent->id, $invoice->id, null, $subscription->id);
                wp_send_json_success([
                    'message' => 'Subscription created successfully.',
                    'subscription_id' => $subscription->id,
                    'invoice_id' => $invoice->id,
                ]);
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            $this->setOrder('error', 'many_payments', null, null, $e->getMessage());
            error_log('Subscription creation error: ' . $e->getMessage());
            wp_send_json_error(['message' => 'Error creating subscription: ' . $e->getMessage()]);
        }
    }

    private function createInvoice() {
        try {
            // Create invoice item
            $invoiceItem = \Stripe\InvoiceItem::create([
                'customer' => $this->args['customer_id'],
                'price' => $this->args['price_id'],
                'quantity' => 1,
            ]);

            // Create invoice
            $invoice = \Stripe\Invoice::create([
                'customer' => $this->args['customer_id'],
                'auto_advance' => false, // Prevent auto-finalization
                'metadata' => [
                    'origin' => $this->args['origin'],
                    'app_payment_method'=> 'one_time',
                    'support_agent' => $this->args['support_agent'],
                    'transaction_id' => base64_encode(date("Y-m-d H:i:s")),
                ],
            ]);

            // Retrieve and finalize the invoice
            $retrievedInvoice = \Stripe\Invoice::retrieve($invoice->id);
            $finalizedInvoice = $retrievedInvoice->finalizeInvoice();

            if ($finalizedInvoice->status === 'open') {
                // If the invoice is open, create a payment intent
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $finalizedInvoice->amount_due,
                    'currency' => $this->args['currency'],
                    'customer' => $this->args['customer_id'],
                    'payment_method' => $this->args['payment_method_id'],
                    'confirm' => true,
                    'setup_future_usage' => 'off_session',
                    'return_url' => $this->args['thank_you_page'],
                ]);
            } elseif ($finalizedInvoice->status === 'paid') {
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $finalizedInvoice->amount_due,
                    'currency' => $this->args['currency'],
                    'customer' => $this->args['customer_id'],
                    'payment_method' => $this->args['payment_method_id'],
                    'confirm' => true,
                    'setup_future_usage' => 'off_session',
                    'return_url' => $this->args['thank_you_page'],
                ]);
            }

            // Handle requires_action status
            if ($paymentIntent->status === 'requires_action') {
                wp_send_json_success([
                    'requires_action' => true,
                    'payment_intent_client_secret' => $paymentIntent->client_secret,
                    'message' => 'Invoice requires additional authentication.',
                ]);
            } elseif ($paymentIntent->status === 'succeeded') {
                wp_send_json_success([
                    'message' => 'Invoice paid successfully.',
                    'invoice_id' => $finalizedInvoice->id,
                ]);
            } else {
                wp_send_json_error(['message' => 'Invoice not open for payment.']);
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            error_log('Invoice processing error: ' . $e->getMessage());
            wp_send_json_error(['message' => 'Error processing invoice: ' . $e->getMessage()]);
        }
    }

    private function setOrder($status, $payment_type, $paymentIntent = null, $invoice_id = null, $error = null, $subscription_id = null) {
        $title = $payment_type === 'many_payments' ? 'Subscription: ' . $subscription_id : 'Order: ' . $paymentIntent;
        if (!empty($error)) {
            $title = $error;
        }

        $order_post = [
            'post_title' => $title,
            'post_content' => 'Payment Intent ID: ' . $paymentIntent,
            'post_status' => 'publish',
            'post_type' => $payment_type === 'many_payments' ? 'subscription' : 'order',
        ];
        wp_insert_post($order_post);
    }
}

function stripe_process_payment_action() {
    if (strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } else {
        $data = $_POST;
    }

    if (!isset($data['nonce1']) || !wp_verify_nonce($data['nonce1'], 'stripe_payment_nonce')) {
        wp_send_json_error(['message' => 'Invalid nonce']);
        wp_die();
    }

    $args = [
        'page_id' => isset($data['page_id']) ? intval($data['page_id']) : 0,
        'product' => sanitize_text_field(get_post_meta($data['page_id'], 'product', true)),
        'total_payments' => isset($data['payments']) ? sanitize_text_field($data['payments']) : '',
        'email' => isset($data['email']) ? sanitize_email($data['email']) : '',
        'name' => isset($data['firstName']) ? sanitize_text_field($data['firstName']) : '',
        'lname' => isset($data['lastName']) ? sanitize_text_field($data['lastName']) : '',
        'phone' => isset($data['phone']) ? sanitize_text_field($data['phone']) : '',
        'price_id' => isset($data['price_id']) ? sanitize_text_field($data['price_id']) : '',
        'support_agent' => isset($data['support_agent']) ? sanitize_text_field($data['support_agent']) : '',
        'thank_you_page' => esc_url(get_post_meta($data['page_id'], 'thankyou', true)),
        'coupon_code' => isset($data['coupon']) ? sanitize_text_field($data['coupon']) : '',
        'payment_method_id' => isset($data['payment_method_id']) ? sanitize_text_field($data['payment_method_id']) : '',
        'origin' => 'API_VER2',
    ];

    if (empty($args['thank_you_page'])) {
        $args['thank_you_page'] = home_url('/thank-you');
    }

    $processor = new StripePaymentProcessor($args);
    $processor->processPayment();

    wp_die();
}

add_action('wp_ajax_stripe_process_payment', 'stripe_process_payment_action');
add_action('wp_ajax_nopriv_stripe_process_payment', 'stripe_process_payment_action');