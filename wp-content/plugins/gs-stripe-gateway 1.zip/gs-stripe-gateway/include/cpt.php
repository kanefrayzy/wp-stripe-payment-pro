<?php
if (!defined('ABSPATH')) die();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function create_subscription_cpt() {
    $labels = [
        'name'                  => 'הוראות קבע',
        'singular_name'         => 'הוראת קבע',
        'menu_name'             => 'הוראות קבע',
        'name_admin_bar'        => 'הוראת קבע',
        'add_new'               => 'הוסף חדש',
        'add_new_item'          => 'הוסף הוראת קבע חדשה',
        'new_item'              => 'הוראת קבע חדשה',
        'edit_item'             => 'ערוך הוראת קבע',
        'view_item'             => 'צפה בהוראת קבע',
        'all_items'             => 'כל הוראות הקבע',
        'search_items'          => 'חפש הוראת קבע',
        'not_found'             => 'לא נמצאו הוראות קבע',
        'not_found_in_trash'    => 'לא נמצאו הוראות קבע באשפה',
    ];

    $args = [
        'labels'                => $labels,
        'public'                => true,
        'has_archive'           => true,
        'rewrite'               => ['slug' => 'subscription'], // Change slug as needed
        'show_in_rest'          => true, // For Gutenberg and REST API support
        'supports'              => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-money-alt',
    ];

    register_post_type('subscription', $args);
}
add_action('init', 'create_subscription_cpt');

function create_order_cpt() {
    $labels = [
        'name'                  => 'הוראות קבע',
        'singular_name'         => 'הוראת קבע',
        'menu_name'             => 'הוראות קבע',
        'name_admin_bar'        => 'הוראת קבע',
        'add_new'               => 'הוסף חדש',
        'add_new_item'          => 'הוסף הוראת קבע חדשה',
        'new_item'              => 'הוראת קבע חדשה',
        'edit_item'             => 'ערוך הוראת קבע',
        'view_item'             => 'צפה בהוראת קבע',
        'all_items'             => 'כל הוראות הקבע',
        'search_items'          => 'חפש הוראת קבע',
        'not_found'             => 'לא נמצאו הוראות קבע',
        'not_found_in_trash'    => 'לא נמצאו הוראות קבע באשפה',
    ];

    $args = [
        'labels'                => $labels,
        'public'                => true,
        'has_archive'           => true,
        'rewrite'               => ['slug' => 'subscription'], // Change slug as needed
        'show_in_rest'          => true, // For Gutenberg and REST API support
        'supports'              => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-money-alt',
    ];

    register_post_type('order', $args);
}
add_action('init', 'create_subscription_cpt');

function create_payment_pages_cpt() {
    $labels = [
        'name'                  => 'עמודי תשלום',
        'singular_name'         => 'עמוד תשלום',
        'menu_name'             => 'עמודי תשלום',
        'name_admin_bar'        => 'עמוד תשלום',
        'add_new'               => 'הוסף חדש',
        'add_new_item'          => 'הוסף עמוד תשלום חדש',
        'new_item'              => 'עמוד תשלום חדש',
        'edit_item'             => 'ערוך עמוד תשלום',
        'view_item'             => 'צפה בעמוד תשלום',
        'all_items'             => 'כל עמודי התשלום',
        'search_items'          => 'חפש עמודי תשלום',
        'not_found'             => 'לא נמצאו עמודי תשלום',
        'not_found_in_trash'    => 'לא נמצאו עמודי תשלום באשפה',
    ];

    $args = [
        'labels'                => $labels,
        'public'                => true,
        'has_archive'           => true,
        'rewrite'               => ['slug' => 'payment-pages'], // Change slug as needed
        'show_in_rest'          => true, // For Gutenberg and REST API support
        'supports'              => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-money-alt',
    ];

    register_post_type('payment_pages', $args);
}
add_action('init', 'create_payment_pages_cpt');

function add_custom_fields_meta_box() {
    add_meta_box(
        'custom_fields_meta_box',        // Unique ID
        'Payment and Price Information',  // Box title
        'display_custom_fields_meta_box', // Content callback
        ['page','payment_pages'],         // Post type
        'side',                           // Context (e.g., side, normal)
        'default'                         // Priority
    );
}


function display_custom_fields_meta_box($post) {
    // Retrieve current values if they exist
    $crm_product_id = get_post_meta($post->ID, 'crm_product_id', true) ?? '';
    $product     = get_post_meta($post->ID, 'product', true) ?? '';
    $full_price  = get_post_meta($post->ID, 'full_price', true) ?? '';
    $crm_send    = get_post_meta($post->ID, 'crm_send', true) ?? '';
    $image       = get_post_meta($post->ID, 'image', true) ?? '';
	$testmode    = get_post_meta($post->ID, 'testmode', true) ?? '';
    $thankyou    = get_post_meta($post->ID, 'thankyou', true) ?? '';

    // Display fields
    ?>
    <p>
        <label for="crm_product_ID">Crm Product ID:</label>
        <input type="text" style="width: 100%;" id="crm_product_id" name="crm_product_id" value="<?php echo esc_attr($crm_product_id); ?>" />
    </p>
    <p>
        <label for="product">Product ID:</label>
        <input type="text" id="product" name="product" value="<?php echo esc_attr($product); ?>" />
    </p>
    <!--p>
        <label for="Full Price">Full Price:</label>
        <input type="text" id="full_price" name="full_price" value="< ?php echo esc_attr($full_price); ?>" /-->
    </p>
    <p>
        <label for="rows">Send To Crm:</label>
        <input type="checkbox" id="crm_send" name="crm_send" value="1" <?php checked($crm_send, '1'); ?> />
    </p>
    <p>
        <label for="image">Image:</label>
        <input type="checkbox" id="image" name="image" value="1" <?php checked($image, '1'); ?> />
    </p>
	<p>
        <label for="image">Test:</label>
        <input type="checkbox" id="testmode" name="testmode" value="1" <?php checked($testmode, '1'); ?> />
    </p>
    <p>
        <label for="thankyou">Thank You Page:</label>
        <input type="text" id="thankyou" name="thankyou" value="<?php echo esc_attr($thankyou); ?>" />
    </p>
    <?php
}

add_action('add_meta_boxes', 'add_custom_fields_meta_box');

function save_custom_fields_meta_box_data($post_id) {
    // Check for autosave or other conditions
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!isset($_POST['product'])) return;
    if (!current_user_can('edit_post', $post_id)) return;

    // Sanitize and save the values
    update_post_meta($post_id, 'crm_product_id', sanitize_text_field($_POST['crm_product_id']));
    update_post_meta($post_id, 'product', sanitize_text_field($_POST['product']));
    update_post_meta($post_id, 'full_price', sanitize_text_field($_POST['full_price']));
    update_post_meta($post_id, 'crm_send', isset($_POST['crm_send']) ? '1' : '0');
	update_post_meta($post_id, 'testmode', isset($_POST['testmode']) ? '1' : '0');
    update_post_meta($post_id, 'image', isset($_POST['image']) ? '1' : '0');
    update_post_meta($post_id, 'thankyou', sanitize_text_field($_POST['thankyou']));
}

add_action('save_post', 'save_custom_fields_meta_box_data');


// יצירת עמוד חדש תחת "כלים"
add_action('admin_menu', 'custom_tools_menu_page');
function custom_tools_menu_page() {
    add_submenu_page(
        'tools.php',                 // הורה (tools)
        'Custom Tools Settings',      // כותרת העמוד
        'Custom Tools',               // שם התפריט
        'manage_options',             // הרשאות נדרשות
        'custom-tools-settings',      // מזהה ייחודי לעמוד
        'custom_tools_settings_page'  // פונקציה להצגת התוכן בעמוד
    );
}

// תצוגת עמוד ההגדרות
function custom_tools_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Custom Tools Settings', 'textdomain'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('custom_tools_settings_group');
            do_settings_sections('custom-tools-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}


// רישום ההגדרות וההגדרות המותאמות
add_action('admin_init', 'custom_tools_settings_init');
function custom_tools_settings_init() {
    // רישום הגדרות
    register_setting('custom_tools_settings_group', 'product_key_field_dev');
    register_setting('custom_tools_settings_group', 'product_key_field_prod');
	
	register_setting('custom_tools_settings_group', 'public_key_field_dev');
	register_setting('custom_tools_settings_group', 'public_key_field_prod');
	
    register_setting('custom_tools_settings_group', 'env_selection');  // עדכון השדה לצ'קבוקס

    // הוספת סעיף הגדרות
    add_settings_section(
        'custom_tools_settings_section',
        __('Custom Tools Options', 'textdomain'),
        'custom_tools_settings_section_callback',
        'custom-tools-settings'
    );

    // הוספת השדות בהתאמה, תלוי במצב הסביבה (DEV/PROD)
    //$checked = get_option('env_selection', false); // בודק את הסביבה שנבחרה
    //if($checked == 1){
        add_settings_field(
            'product_key_field_dev',
            __('Products', 'textdomain'),
            'fields_callback',
            'custom-tools-settings',
            'custom_tools_settings_section',
            ['field_name' => 'product_key_field_dev', 'default_value' => '', 'field_type' => 'password']
        );
        add_settings_field(
            'public_key_field_dev',
            __('Public Key', 'textdomain'),
            'fields_callback',
            'custom-tools-settings',
            'custom_tools_settings_section',
            ['field_name' => 'public_key_field_dev', 'default_value' => '', 'field_type' => 'password']
        );
    //} else {
        add_settings_field(
            'product_key_field_prod',
            __('Products', 'textdomain'),
            'fields_callback',
            'custom-tools-settings',
            'custom_tools_settings_section',
            ['field_name' => 'product_key_field_prod', 'default_value' => '', 'field_type' => 'password']
        );
        add_settings_field(
            'public_key_field_prod',
            __('Public Key', 'textdomain'),
            'fields_callback',
            'custom-tools-settings',
            'custom_tools_settings_section',
            ['field_name' => 'public_key_field_prod', 'default_value' => '', 'field_type' => 'password']
        );
    //}

    // תיבת סימון מותאמת (צ'קבוקס)
    /*add_settings_field(
        'env_selection',
        __('Test Mode', 'textdomain'),
        'fields_callback',
        'custom-tools-settings',
        'custom_tools_settings_section',
        ['field_name' => 'env_selection', 'default_value' => '', 'field_type' => 'checkbox']
    );*/
}

// סעיף הגדרות מותאם
function custom_tools_settings_section_callback() {
    echo '<p>' . __('Configure your custom tools options here.', 'textdomain') . '</p>';
}

// פונקציה כללית עבור שדות מותאמים לפי סוג
function fields_callback($args) {
    $field_name = $args['field_name'];
    $default_value = $args['default_value'];
    $field_type = $args['field_type'];
    $value = get_option($field_name, $default_value);

    // הצגת כוכביות או טקסט דמי במקום המפתח
    if ($field_type != 'checkbox') {
        if (!empty($value)) {
            // אם הערך מוצפן, הצג כוכביות
            if (preg_match('/^[A-Za-z0-9+\/=]*$/', $value)) { // מוודא שהערך מוצפן ב-base64
                echo '<input type="' . esc_attr($field_type) . '" name="' . esc_attr($field_name) . '" value="********" />';
            } else {
                echo '<input type="' . esc_attr($field_type) . '" name="' . esc_attr($field_name) . '" value="' . esc_attr($value) . '" />';
            }
        } else {
            // אם אין ערך, הצג כוכביות או טקסט דמי
            echo '<input type="' . esc_attr($field_type) . '" name="' . esc_attr($field_name) . '" value="********" />';
        }
    } else {
        // הצגת תיבת סימון (checkbox)
        //$checked = get_option($field_name, false);
        //echo '<input type="checkbox" name="' . esc_attr($field_name) . '" value="1" ' . checked(1, $checked, false) . ' />';
    }
}



// 1. הוספת העמודה לרשימת ה-CPT
add_filter('manage_payment_pages_posts_columns', 'add_custom_column');
function add_custom_column($columns) {
    $columns['custom_field_column'] = 'Enviorment'; // שם העמודה
    return $columns;
}

// 2. מילוי הערך בעמודה עבור כל פוסט
add_action('manage_payment_pages_posts_custom_column', 'populate_custom_column', 10, 2);
function populate_custom_column($column, $post_id) {
    if ('custom_field_column' === $column) {
        $custom_field_value = get_post_meta($post_id, 'testmode', true);
		$crm_product_id     = get_post_meta($post_id, 'crm_product_id', true);
		
		if($custom_field_value == 1){
			echo '<div style="background:yellow;float:right;padding: 6px 10px;">טסט</div>';
		}
		else{
			echo '<div style="background: green;float:right;padding: 6px 10px;color: #fff;">פרוד</div>';
		}
		
		if(empty($crm_product_id)){
			echo '<div style="background:red;float:right;padding: 6px 10px;color:#fff;">שדה מזהה מוצר פיירברי ריק!</div>';
		}
        
    }
}

// 3. להבטיח שהעמודה ניתנת למיון
add_filter('manage_edit-payment_pages_sortable_columns', 'make_custom_column_sortable');
function make_custom_column_sortable($columns) {
    $columns['custom_field_column'] = 'custom_field_column';
    return $columns;
}