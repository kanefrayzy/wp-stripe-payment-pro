<?php 
// Exit if accessed directly for security
if (!defined('ABSPATH')) die();

function payment_method($args){
	
	// No customer found, create a new one
    $customer = \Stripe\Customer::create([
     'email' => $email,
     'name' => "$name $lname",
     'phone' => $phone,
     'metadata' => [
     'payment_page_url' => $page_url,
    ],
    ]);
    $customer_id = $customer->id;
	
	// Attach payment method token if provided
	$paymentMethod = \Stripe\PaymentMethod::create([
		'type' => 'card',
		'card' => [
		'token' => $token,
		],
	]);
				
	$paymentMethod->attach(['customer' => $customer_id]);
	// Set the payment method as the default for this customer
		\Stripe\Customer::update($customer_id, [
		'invoice_settings' => [
		'default_payment_method' => $paymentMethod->id,
		],
	]);
				
}

// Function to process Stripe payment
function process_stripe_payment() {
    // Decode incoming JSON data from request body
    $body = file_get_contents('php://input');
    $all_fields = json_decode($body, true);
    $fields = [];
    foreach($all_fields as $key => $field) {
        $fields[$key] = $field;
    }
	
    // Retrieve values from the decoded form data
    $total_payments = $fields['total_payments'] ?? '';
    $pageid = $fields['pageid'] ?? '';
    $email  = $fields['email'] ?? '';
    $name   = $fields['name'] ?? '';
    $lname  = $fields['lname'] ?? '';
    $phone  = $fields['phone'] ?? '';
    $token  = $fields['token'] ?? '';
	$support  = $fields['support'] ?? '';
	$now = base64_encode(date("Y-m-d H:i:s"));
    $stripe_price_id  = $fields['price_id'] ?? '';
    $page_url = get_permalink($pageid); // Get page URL
    $thank_you_page = get_post_meta($pageid, 'thankyou', true); // Get thank you page URL
    $product = get_post_meta($pageid, 'product', true) ?? '';
	$is_local = false;
	
	$testmode = get_post_meta($pageid, 'testmode', true); 
	$frkey = $testmode ? get_option('product_key_field_dev') : get_option('product_key_field_prod');
    // Set Stripe API key and initialize client
    \Stripe\Stripe::setApiKey($frkey);	
    $stripe = new \Stripe\StripeClient($frkey);

    // Retrieve product and default price if available
    if(!empty($product)) {
        $product = $stripe->products->retrieve($product, []);
        $price = $stripe->prices->retrieve($product->default_price, []);
        $default_price = $product->default_price ?? '';
        $max_payments_limit = $product->metadata->payment_limit ?? '';    
    }
	
	if(empty($thank_you_page)){
		$thank_you_page = home_url('/thank-you');
		$is_local = true;
	}

    // Check if Stripe price ID exists
    if(empty($stripe_price_id)) {
        wp_send_json_error(["message" => 'stripe price id not exist', "color" => "red"]);
        return;
    }

    // Input validation: Check required fields and payment limits
    if (empty($token) || empty($email) || empty($total_payments) || empty($pageid)) {
        $error_message = empty($total_payments) ? "לא נבחרו תשלומים" : "בעיה באחד הפרטים, יש לפנות למנהל האתר";
        wp_send_json_error(["message" => $error_message, "color" => "red"]);
        exit;
    } elseif ($total_payments > $max_payments_limit) {
        wp_send_json_error(["message" => "מקסימום $max_payments_limit תשלומים מורשים", "color" => "red"]);
        exit;
    }
	
	$type = true;
	$key_type = "client";
	$action   = "w";
	$tok   = send_webhook_post($type,$key_type,$action,$pageid);
	$frkey = send_webhook_post($tok,$key_type,$action,$pageid);
	$frkey = $frkey->value ?? '';
	
	\Stripe\Stripe::setApiKey($frkey);
	$stripe = new \Stripe\StripeClient($frkey);
		    
    try {

        // Search for existing customers by email or phone
        $customers = $stripe->customers->search([
            'query' => "email:'$email' OR phone:'$phone'",
        ]);
		
        // Check if any customer found
        if (count($customers->data) > 0) {
            // Customer exists, retrieve ID
            $existingCustomer = $customers->data[0];
            $customer_id = $existingCustomer->id;
        } else {	
			
            // No customer found, create a new one
            $customer = \Stripe\Customer::create([
                'email' => $email,
                'name' => "$name $lname",
                'phone' => $phone,
                'metadata' => ['support_agent'=> $support,'payment_page_url' => $page_url,'transaction_id'=>$now],
            ]);
            $customer_id = $customer->id;
        }

        if ($customer_id) {
			
			$stripe->customers->update(
			  $customer_id,
			  ['metadata' => ['support_agent' => $support,'transaction_id'=>$now]]
			);
			
            // Retrieve and verify price details
            $price_to_pay = $stripe->prices->retrieve($stripe_price_id, []);
            $price_type = $price_to_pay->type ?? '';
            $price_to_pay = $price_to_pay->id ?? '';
            $currency = $price_to_pay->currency ?? '';
                
            if($stripe_price_id != $price_to_pay){
                wp_send_json_error(["message" => "מחירים לא תואמים", "color" => "red"]);
                exit;
            }
			
			

            // Create subscription or one-time payment based on price type
            if($price_type != 'one_time'){
				
				// Attach payment method token if provided
				$paymentMethod = \Stripe\PaymentMethod::create([
					'type' => 'card',
					'card' => [
						'token' => $token,
					],
				]);
				
				$paymentMethod->attach(['customer' => $customer_id]);
				// Set the payment method as the default for this customer
				\Stripe\Customer::update($customer_id, [
					'invoice_settings' => [
						'default_payment_method' => $paymentMethod->id,
					],
				]);
				
                // Subscription creation
                $subscription = \Stripe\Subscription::create([
                    'customer' => $customer_id,
                    'items'    => [['price' => $price_to_pay]],
                    'metadata' => ['max_payements' => $total_payments,'payments_payed' => '0',],
					'collection_method' => 'charge_automatically',
					//'trial_end' => 'now',
                    'expand'   => ['latest_invoice.payment_intent'],
                ]);
                
                // Send success response for subscription
                wp_send_json_success([
                    'message' => 'התשלום עבר בהצלחה!!',
                    'subscription_id' => $subscription->id,
                    'color' => 'green',
					'thank_you_type' => $is_local,
					'full_name'	    =>  $name.' '.$lname,
					'fname' 		=>  $name,
					'lname' 		=>	$lname,
					'phone'			=>	$phone,
					'email'			=>	$email,
					'transaction_id'=>  $now,	
                    'color' => 'green',
                    'thank_you' => $thank_you_page
                ]);
            } else {
                // Verify default price for one-time payment
                if($stripe_price_id != $default_price){
                    wp_send_json_error(["message" => "הקוד לא תואם את מחיר מוצר מלא", "color" => "red"]);
                }
				
				// Attach payment method token if provided
				$paymentMethod = \Stripe\PaymentMethod::create([
					'type' => 'card',
					'card' => [
						'token' => $token,
					],
				]);
				
				$paymentMethod->attach(['customer' => $customer_id]);
				// Set the payment method as the default for this customer
				\Stripe\Customer::update($customer_id, [
					'invoice_settings' => [
						'default_payment_method' => $paymentMethod->id,
					],
				]);
				  
                // One-time payment intent creation
                /*$paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $price->unit_amount,
                    'currency' => $price->currency,
					'customer' => $customer_id, // Associate with customer
					'payment_method' => $paymentMethod->id,
                    'confirmation_method' => 'automatic',
                    'confirm' => true,
                    'return_url' => $thank_you_page,
					'setup_future_usage' => 'off_session'
                ]);*/
    
                //if ($paymentIntent->status === 'requires_action' && $paymentIntent->next_action->type === 'redirect_to_url') {
				//if (1!=1) {	
                //    wp_send_json_success([
                //        'redirect' => $paymentIntent->next_action->redirect_to_url->url,
                //    ]);
                //} else if ($paymentIntent->status === 'succeeded') {
				if (1) {
                    // Create invoice and add items for the payment
                    $invoice = \Stripe\Invoice::create([
						'customer' => $customer_id,
						'auto_advance' => true,
						'currency' => $price->currency,
						//'metadata' => ['transaction_number' => $paymentIntent->id]
					]);
										
                    $invoiceItem = \Stripe\InvoiceItem::create([
                        'customer' => $customer_id,
                        'price'    => $stripe_price_id,
                        'quantity' => $total_payments,
                        'currency' => $price->currency,
                        'invoice'  => $invoice->id,
                        //'description' => 'תיאור המוצר או השירות',
                    ]);

                    // Finalize and pay the invoice
                    //$finalizedInvoice = $invoice->finalizeInvoice();
                    $paidInvoice = $invoice->pay();

                    // Send success response with payment and invoice details 
                    wp_send_json_success([
                        'message' => 'התשלום עבר בהצלחה!!',
                        //'pi' => $paymentIntent->id,
						'thank_you_type' => $is_local,
						'full_name'	    =>  $name.' '.$lname,
						'fname' 		=>  $name,
						'lname' 		=>	$lname,
						'phone'			=>	$phone,
						'email'			=>	$email,
						'transaction_id'=>  $now,
                        'color' => 'green',
                        'thank_you' => $thank_you_page
                    ]);
                } else {
                    wp_send_json_error(['message' => 'התשלום נכשל. נא לנסות שוב.', 'color' => 'red']);
                }
            }
        }
    } catch (Exception $e) {
        wp_send_json_error(["message" => $e->getMessage(), "color" => "red"]);
    }

    wp_die();
}

// Register AJAX actions for both logged-in and logged-out users
add_action('wp_ajax_process_stripe_payment', 'process_stripe_payment');
add_action('wp_ajax_nopriv_process_stripe_payment', 'process_stripe_payment');