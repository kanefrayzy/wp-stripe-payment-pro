<?php
if (!defined('ABSPATH')) die();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



function create_custom_cpt($cpt_name, $labels, $args) {
    $args['labels'] = $labels;
    register_post_type($cpt_name, $args);
}

add_action('init', function() {

    $payment_labels = [
        'name'                  => 'עמודי תשלום',
        'singular_name'         => 'עמוד תשלום',
        'menu_name'             => 'עמודי תשלום',
        'name_admin_bar'        => 'עמוד תשלום',
        'add_new'               => 'הוסף חדש',
        'add_new_item'          => 'הוסף עמוד תשלום חדש',
        'new_item'              => 'עמוד תשלום חדש',
        'edit_item'             => 'ערוך עמוד תשלום',
        'view_item'             => 'צפה בעמוד תשלום',
        'all_items'             => 'כל עמודי התשלום',
        'search_items'          => 'חפש עמודי תשלום',
        'not_found'             => 'לא נמצאו עמודי תשלום',
        'not_found_in_trash'    => 'לא נמצאו עמודי תשלום באשפה',
    ];

    $payment_args = [
        'public'                => true,
        'has_archive'           => true,
        'rewrite'               => ['slug' => 'payment-pages'], // Change slug as needed
        'show_in_rest'          => true, // For Gutenberg and REST API support
        'supports'              => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-money-alt',
    ];

    create_custom_cpt('payment_pages', $payment_labels, $payment_args);
    
    $order_labels = [
        'name'                  => 'הזמנות',
        'singular_name'         => 'הזמנה',
        'menu_name'             => 'הזמנות',
        'name_admin_bar'        => 'הזמנה',
        'add_new'               => 'הוסף חדש',
        'add_new_item'          => 'הוסף הזמנה חדשה',
        'new_item'              => 'הזמנה חדשה',
        'edit_item'             => 'ערוך הזמנה',
        'view_item'             => 'צפה בהזמנה',
        'all_items'             => 'כל ההזמנות',
        'search_items'          => 'חפש הזמנה',
        'not_found'             => 'לא נמצאו הזמנות',
        'not_found_in_trash'    => 'לא נמצאו הזמנות באשפה',
    ];

    $order_args = [
        'public'                => true,
        'has_archive'           => true,
        'rewrite'               => ['slug' => 'order'],
        'show_in_rest'          => true,
        'supports'              => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-money-alt',
    ];

    create_custom_cpt('order', $order_labels, $order_args);

    $subscription_labels = [
        'name'                  => 'הוראות קבע',
        'singular_name'         => 'הוראת קבע',
        'menu_name'             => 'הוראות קבע',
        'name_admin_bar'        => 'הוראת קבע',
        'add_new'               => 'הוסף חדש',
        'add_new_item'          => 'הוסף הוראת קבע חדשה',
        'new_item'              => 'הוראת קבע חדשה',
        'edit_item'             => 'ערוך הוראת קבע',
        'view_item'             => 'צפה בהוראת קבע',
        'all_items'             => 'כל הוראות הקבע',
        'search_items'          => 'חפש הוראת קבע',
        'not_found'             => 'לא נמצאו הוראות קבע',
        'not_found_in_trash'    => 'לא נמצאו הוראות קבע באשפה',
    ];

    $subscription_args = [
        'public'                => true,
        'has_archive'           => true,
        'rewrite'               => ['slug' => 'subscription'],
        'show_in_rest'          => true,
        'supports'              => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-money-alt',
    ];

    create_custom_cpt('subscription', $subscription_labels, $subscription_args);
});



function add_custom_fields_meta_box($cpt_name, $fields) {
    add_meta_box(
        'custom_fields_meta_box',        // Unique ID
        'Custom Fields',                 // Box title
        function($post) use ($fields) { display_custom_fields_meta_box($post, $fields); }, // Content callback
        $cpt_name,                       // Post type
        'side',                          // Context (e.g., side, normal)
        'default'                        // Priority
    );
}

function display_custom_fields_meta_box($post, $fields) {
    foreach ($fields as $field) {
        $value = get_post_meta($post->ID, $field['id'], true) ?? '';
        ?>
        <p>
            <label for="<?php echo esc_attr($field['id']); ?>"><?php echo esc_html($field['label']); ?>:</label>
            <input type="text" style="width: 100%;" id="<?php echo esc_attr($field['id']); ?>" name="<?php echo esc_attr($field['id']); ?>" value="<?php echo esc_attr($value); ?>" />
        </p>
        <?php
    }
}

function save_custom_fields_meta_box_data($post_id, $fields) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    foreach ($fields as $field) {
        if (isset($_POST[$field['id']])) {
            update_post_meta($post_id, $field['id'], sanitize_text_field($_POST[$field['id']]));
        }
    }
}

function add_custom_columns($columns, $fields) {
    foreach ($fields as $field) {
        $columns[$field['id']] = $field['label'];
    }
    return $columns;
}

function populate_custom_columns($column, $post_id, $fields) {
    foreach ($fields as $field) {
        if ($column === $field['id']) {
            echo esc_html(get_post_meta($post_id, $field['id'], true));
        }
    }
}

function make_custom_columns_sortable($columns, $fields) {
    foreach ($fields as $field) {
        $columns[$field['id']] = $field['id'];
    }
    return $columns;
}

$custom_fields = [
    ['id' => 'customer_name', 'label' => 'Customer Name'],
    ['id' => 'subscription_id', 'label' => 'Subscription ID'],
    ['id' => 'payment_intent_id', 'label' => 'Payment Intent ID'],
    ['id' => 'wp_order_id', 'label' => 'WP Order ID'],
    ['id' => 'status', 'label' => 'Status'],
];

add_action('add_meta_boxes', function() use ($custom_fields) {
    add_custom_fields_meta_box(['order', 'subscription'], $custom_fields);
});

add_action('save_post', function($post_id) use ($custom_fields) {
    save_custom_fields_meta_box_data($post_id, $custom_fields);
});



add_filter('manage_subscription_posts_columns', function($columns) use ($custom_fields) {
    return add_custom_columns($columns, $custom_fields);
});
add_action('manage_subscription_posts_custom_column', function($column, $post_id) use ($custom_fields) {
    populate_custom_columns($column, $post_id, $custom_fields);
}, 10, 2);
add_filter('manage_edit-subscription_sortable_columns', function($columns) use ($custom_fields) {
    return make_custom_columns_sortable($columns, $custom_fields);
});

add_filter('manage_order_posts_columns', function($columns) use ($custom_fields) {
    return add_custom_columns($columns, $custom_fields);
});
add_action('manage_order_posts_custom_column', function($column, $post_id) use ($custom_fields) {
    populate_custom_columns($column, $post_id, $custom_fields);
}, 10, 2);

add_filter('manage_edit-order_sortable_columns', function($columns) use ($custom_fields) {
    return make_custom_columns_sortable($columns, $custom_fields);
});

/* @TODO: Replace to new method of fields and coloumns */
// 1. הוספת העמודה לרשימת ה-CPT
add_filter('manage_payment_pages_posts_columns', 'add_custom_column');
function add_custom_column($columns) {
    $columns['custom_field_column'] = 'Enviorment'; // שם העמודה
    return $columns;
}

// 2. מילוי הערך בעמודה עבור כל פוסט
add_action('manage_payment_pages_posts_custom_column', 'populate_custom_column', 10, 2);
function populate_custom_column($column, $post_id) {
    if ('custom_field_column' === $column) {
        $custom_field_value = get_post_meta($post_id, 'testmode', true);
		$crm_product_id     = get_post_meta($post_id, 'crm_product_id', true);
		
		if($custom_field_value == 1){
			echo '<div style="background:yellow;float:right;padding: 6px 10px;">טסט</div>';
		}
		else{
			echo '<div style="background: green;float:right;padding: 6px 10px;color: #fff;">פרוד</div>';
		}
		
		if(empty($crm_product_id)){
			echo '<div style="background:red;float:right;padding: 6px 10px;color:#fff;">שדה מזהה מוצר פיירברי ריק!</div>';
		}
        
    }
}

// 3. להבטיח שהעמודה ניתנת למיון
add_filter('manage_edit-payment_pages_sortable_columns', 'make_custom_column_sortable');
function make_custom_column_sortable($columns) {
    $columns['custom_field_column'] = 'custom_field_column';
    return $columns;
}

