<?php if (!defined('ABSPATH')) die(); ?>

<div class="right-column">
<!-- Payment form -->
<form id="payment-form">
    <div class="form_inline_fields">
        <input type="text" id="name" placeholder="שם פרטי" required>
        <input type="text" id="lname" placeholder="שם משפחה" required>
    </div>
    <div class="form_inline_fields">
    <input type="email" id="email" placeholder="אימייל" required>
    <input type="tel" id="phone" placeholder="טלפון" required>
    </div>
	
    <div id="card-number-element" class="stripe-element"></div>
    <div class="stripe-card-elements">
    <div id="card-expiry-element" class="stripe-element"></div>
    <div id="card-cvc-element" class="stripe-element"></div>
    </div>
    <div class="form_inline_fields">
	<select id="support">
    <option value="לא נבחר">מי עזר לך להירשם?</option>
    <option value="אף אחד לא עזר לי">אף אחד לא עזר לי</option>
    <option value="אליהו ויצמן">אליהו ויצמן</option>
    <option value="אורטל גרגו">אורטל גרגו</option>
    <option value="איריס ביבי">איריס ביבי</option>
    <option value="אתי ינאי">אתי ינאי</option>
    <option value="בקי סבן">בקי סבן</option>
    <option value="גאיה תמיר">גאיה תמיר</option>
    <option value="ג'ולייט אליהו">ג'ולייט אליהו</option>
    <option value="גלי נס">גלי נס</option>
    <option value="זהרה מריזן">זהרה מריזן</option>
    <option value="טליה הקינן רוז">טליה הקינן רוז</option>
    <option value="לאה דרורי">לאה דרורי</option>
    <option value="מורן רסיוק">מורן רסיוק</option>
    <option value="מירב ויקטורוביץ">מירב ויקטורוביץ</option>
    <option value="עינת פאר">עינת פאר</option>
    <option value="ראבה">ראבה</option>
    <option value="רונית בת מנחם">רונית בת מנחם</option>
    <option value="רחל בשי">רחל בשי</option>
    <option value="ריקי עמדי">ריקי עמדי</option>
    <option value="שולה בן דוד">שולה בן דוד</option>
    <option value="שולמית רונן">שולמית רונן</option>
    <option value="שני ריף">שני ריף</option>
    <option value="שרון ביחובסקי">שרון ביחובסקי</option>
	</select>
    <!--select id="quantity" class="">
    < ?php 
        $q = 1;
        for ($q=$q; $q <= 1; $q++) { 
            if($q == 0){ ?>
                <option val="< ?php echo $q; ?>">כמות</option>
                < ?php } else { ?>
                    <option data="< ?php echo $q;?>" val="< ?php echo $q; ?>">< ?php echo 'כמות '.$q ?></option> 
                < ?php } ?> 
            < ?php } ?> 
    </select-->
    <select id="payment_selection" class="">
    <?php 
        // Fetch prices from Stripe
        
        try {
            $prices = $stripe->prices->all(['limit' => 36, 'product' => $product, 'active' => true, 'product'=>$product_id]);

            // Check if $prices is an object and has the 'data' property
            if (is_object($prices) && isset($prices->data) && is_array($prices->data)) {
                // Convert the prices to an array for sorting
                $pricesArray = $prices->data;

                // Sort prices by unit_amount in ascending order
                usort($pricesArray, function ($a, $b) {
                    return $b->unit_amount - $a->unit_amount; // Ascending order
                });
                $p = 1;
                // Now you can work with the sorted prices
                foreach ($pricesArray as $payment_price) {
                        if($p == 1): ?>
                            <option data="<?php echo $payment_price->id; ?>" val="<?php echo $p; ?>"><?php echo 'תשלום '.$p ?></option>
                        <?php else:  ?>
                            <option data="<?php echo $payment_price->id; ?>" val="<?php echo $p; ?>"><?php echo $p.' תשלומים' ?></option> 
                        <?php endif; ?>
                        <?php $p++;
                        //echo "Price ID: " . $payment_price->id . " - Amount: " . ($payment_price->unit_amount / 100) . " " . strtoupper($payment_price->currency) . "<br>";
                }
            } else {
                // Log or handle the error if prices data is not available
                error_log('Failed to retrieve prices: ' . print_r($prices, true));
                echo 'No prices found or the response format is incorrect.';
            }
        } catch (\Stripe\Exception\ApiErrorException $e) {
            // Handle Stripe API errors
            error_log('Stripe API error: ' . $e->getMessage());
            echo 'Error fetching prices from Stripe: ' . $e->getMessage();
        } catch (Exception $e) {
            // Handle other exceptions
            error_log('General error: ' . $e->getMessage());
            echo 'An error occurred: ' . $e->getMessage();
        }
    ?> 
    </select>
    </div>
    <input  type="hidden" id="pageid" value="<?php echo $post->ID ?? ''; ?>">
    <input  type="hidden" id="total_payments" value="1">
    <input  type="hidden" id="price" value="<?php echo $price->unit_amount ?? ''; ?>">
    <input  type="hidden" id="price_id" value="<?php echo $price->id ?? ''; ?>">
    <button type="submit" id="submit">לתשלום</button>
    <div id="error-message"></div>
    </div>
</form>
</div>

<!-- Stripe JavaScript library -->
<script src="https://js.stripe.com/v3/"></script>

<script type="text/javascript">
// Initialize Stripe
<?php $pbkey = $testmode ? get_option('public_key_field_dev') : get_option('public_key_field_prod'); ?>
var pb_key = "<?php echo $pbkey ?>";
var stripe = Stripe(pb_key); // Replace with your actual public key
var elements = stripe.elements();


// הגדרת עיצוב בסיסי שיהיה אחיד לכל האלמנטים
var style = {
    base: {
        fontSize: '16px',
        color: '#32325d',
        backgroundColor: '#fff',
        "::placeholder": {
            color: '#aab7c4',
        },
    },
    invalid: {
        color: '#fa755a',  // צבע הטקסט במקרה של שגיאה
        iconColor: '#fa755a', // צבע האייקון במקרה של שגיאה
    }
};

// יצירת האלמנט של מספר הכרטיס עם תמיכה באייקונים של סוג הכרטיס
var cardNumber = elements.create('cardNumber', { style: style, showIcon: true });
cardNumber.mount('#card-number-element');

// יצירת האלמנט של תוקף הכרטיס
var cardExpiry = elements.create('cardExpiry', { style: style });
cardExpiry.mount('#card-expiry-element');

// יצירת האלמנט של קוד ה-CVC
var cardCvc = elements.create('cardCvc', { style: style });
cardCvc.mount('#card-cvc-element');

// טיפול בשגיאות
function handleCardError(event) {
	var textContent = null;
    var errorElement = document.getElementById('card-errors');
    if (event.error) {
        errorElement.textContent = event.error.message;
    } else {
        //errorElement.textContent = '';
    }
}

// מאזינים לשינויים עבור כל אחד מהאלמנטים
cardNumber.on('change', handleCardError);
cardExpiry.on('change', handleCardError);
cardCvc.on('change', handleCardError);


// Handle form submission
document.getElementById('payment-form').addEventListener('submit', function(event) {
    event.preventDefault();
    clearError();
    const submitButton = event.target.querySelector('button[type="submit"]');
    const errorMessage = document.getElementById('error-message');
    errorMessage.classList.remove('active');

    // Disable the submit button to prevent duplicate submissions
    submitButton.disabled = true;

    // Generate Stripe token
    stripe.createToken(cardNumber).then(function(result) {
        if (result.error) {
            displayError(result.error.message);
            submitButton.disabled = false; // Re-enable the button on error
        } else {
            submitForm(result.token.id);
        }
    });
});

// Function to display error messages
function displayError(message) {
    const errorMessage = document.getElementById('error-message');
    errorMessage.textContent = message;
    errorMessage.classList.add('active');
}

// Function to submit form with token to the server
function submitForm(token) {
    document.getElementById('loader').style.display = 'block';

    // Collect form data
    const form = document.getElementById('payment-form');
    const formData = Array.from(form.elements).reduce((data, element) => {
        if (element.id) data[element.id] = element.value;
        return data;
    }, {});

    // Add the token to the form data
    formData.token = token;

    fetch('<?php echo admin_url("admin-ajax.php?action=process_stripe_payment"); ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => handleResponse(data))
    .catch(error => handleError(error))
    .finally(() => {
        document.getElementById('loader').style.display = 'none'; // Hide the loader
    });
}
	
function sendPost(data) {
    const form = document.createElement("form");
    form.method = "POST";

    if (data.thank_you_type === true) {
        form.action = location.origin + "/thank-you/";
    } else {
        form.action = data.thank_you;
    }

    for (const key in data) {
        if (data.hasOwnProperty(key)) {
            const input = document.createElement("input");
            input.type = "hidden";
            input.name = key;
            input.value = data[key];
            form.appendChild(input);
        }
    }

    // Append the form to the document before submitting
    document.body.appendChild(form);

    // Log to confirm form is connected before submission
    console.log("Form connected to DOM, submitting...");

    setTimeout(() => {
    form.submit();
		console.log(form);
	}, 100);
	
}
	
function sendGet(data) {
    // Extract all fields from data and construct query string
    const queryParams = new URLSearchParams();
    for (const key in data) {
        if (data.hasOwnProperty(key)) {
            if (Array.isArray(data[key])) {
                data[key].forEach(value => queryParams.append(key, value));
            } else {
                queryParams.append(key, data[key]);
            }
        }
    }

    // Determine the action URL
    let actionUrl;
    if (data.thank_you_type === true) {
        actionUrl = location.origin + "/thank-you/";
    } else {
        actionUrl = data.thank_you;
    }

    // Append query parameters to the URL
    const urlWithParams = `${actionUrl}?${queryParams.toString()}`;

    // Log the final URL
    console.log("Redirecting to:", urlWithParams);

    // Redirect to the URL
    setTimeout(() => {
        window.location.href = urlWithParams;
        console.log("Redirection done");
    }, 1000);
}
	

// Function to handle server response
function handleResponse(data) {
    const submitButton = document.querySelector('button[type="submit"]'); // Ensure we get the button again

    if (data.success) {
        displayError(data.data.message); // Display success message
        cardNumber.clear(); // Clear card input fields
        cardExpiry.clear();
        cardCvc.clear();
        document.getElementById('error-message').classList.add('green');         
        document.getElementById('payment-form').reset(); // Reset form
		sendPost(data.data);
        submitButton.disabled = false; // Re-enable the button after successful submission
     
    } else {
        displayError(data.data.message); // Display error message
        submitButton.disabled = false; // Re-enable the button on error
    }
}

// Function to handle server error
function handleError(error) {
    console.error('Error:', error);
    displayError('An error occurred. Please try again.');
    const submitButton = document.querySelector('button[type="submit"]'); // Ensure we get the button again
    submitButton.disabled = false; // Re-enable the button on error
}

// Function to clear error messages
function clearError() {
    const errorMessage = document.getElementById('error-message');
    errorMessage.textContent = '';
    errorMessage.classList.remove('active');
}
</script>